﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Отдел_кадров.Entities;
using Отдел_кадров.WinForm;

namespace Отдел_кадров
{
    //BDConnectionString
    public partial class MainForm : Form
    {
        /// <summary>
        /// Инициализация конструктора
        /// </summary>
        public MainForm()
        {
            InitializeComponent();
            this.InfoGrid.DataSource = DataAccess.GetStaffDismiss();
        }

        /// <summary>
        /// Скрываем не нужные колонки и переименновываем те что остались на русский
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void InfoGrid_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            if (this.InfoGrid.Columns["ServiceNumber"] != null)
            {
                this.InfoGrid.Columns["ServiceNumber"].Visible = false;
            }

            if (this.InfoGrid.Columns["Experience"] != null)
            {
                this.InfoGrid.Columns["Experience"].Visible = false;
            }

            if (this.InfoGrid.Columns["DateAcceptance"] != null)
            {
                this.InfoGrid.Columns["DateAcceptance"].Visible = false;
            }

            if (this.InfoGrid.Columns["DateDismissal"] != null)
            {
                this.InfoGrid.Columns["DateDismissal"].Visible = false;
            }

            if (this.InfoGrid.Columns["NameFIO"] != null)
            {
                this.InfoGrid.Columns["NameFIO"].HeaderText = "Ф.И.О";
            }

            if (this.InfoGrid.Columns["Post"] != null)
            {
                this.InfoGrid.Columns["Post"].HeaderText = "Должность";
            }

            if (this.InfoGrid.Columns["Branch"] != null)
            {
                this.InfoGrid.Columns["Branch"].HeaderText = "Филиал";
            }

            if (this.InfoGrid.Columns["DateBirth"] != null)
            {
                this.InfoGrid.Columns["DateBirth"].HeaderText = "День Рождения";
            }

            if (this.InfoGrid.Columns["Department"] != null)
            {
                this.InfoGrid.Columns["Department"].HeaderText = "Отдел";
            }

            if (this.InfoGrid.Columns["AddressResidence"] != null)
            {
                this.InfoGrid.Columns["AddressResidence"].HeaderText = "Адрес прописки";
            }

            if (this.InfoGrid.Columns["Education"] != null)
            {
                this.InfoGrid.Columns["Education"].HeaderText = "Образование";
            }

            if (this.InfoGrid.Columns["CityResidence"] != null)
            {
                this.InfoGrid.Columns["CityResidence"].HeaderText = "Город прописки";
            }
        }

        /// <summary>
        /// Поиск по критерию Сотрудника
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnSearch_Click(object sender, EventArgs e)
        {
          this.InfoGrid.DataSource = DataAccess.GetStaffDismiss(txtFIO.Text,txtPost.Text,txtBranches.Text);
        }

    
        
        /// <summary>
        /// Открываем форму сотрудников
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void StaffToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StaffForm staffForm = new StaffForm();
            staffForm.ShowDialog();
            this.InfoGrid.DataSource = DataAccess.GetStaffDismiss();
        }

        /// <summary>
        /// Открываем форму филиалов
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BranchesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BranchesForm branches = new BranchesForm();
            branches.ShowDialog();
            this.InfoGrid.DataSource = DataAccess.GetStaffDismiss();
        }

        /// <summary>
        /// Открываем форму должностей
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PositionsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PositionsForm positions = new PositionsForm();
            positions.ShowDialog();
            this.InfoGrid.DataSource = DataAccess.GetStaffDismiss();
        }

        /// <summary>
        /// Отчет А
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ReportAForm reportA = new ReportAForm();
            reportA.ShowDialog();
        }

        /// <summary>
        /// Отчет B
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ReportBForm reportB = new ReportBForm();
            reportB.ShowDialog();
        }

        /// <summary>
        /// Отчет C
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ReportCForm reportCForm = new ReportCForm();
            reportCForm.ShowDialog();
        }

        /// <summary>
        /// Отчет D
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ReportDForm reportD = new ReportDForm();
            reportD.ShowDialog();
        }
    }
}
